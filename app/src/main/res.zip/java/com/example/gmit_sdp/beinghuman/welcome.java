package com.example.gmit_sdp.beinghuman;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.facebook.accountkit.AccountKit;

/**
 * Created by Bhaumik on 4/28/2017.
 */

public class welcome extends Activity {
    Button a,b;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AccountKit.initialize(getApplicationContext());
        setContentView(R.layout.welcome);
        final DBAdapter dbAdapter= new DBAdapter(this);
        a=(Button) findViewById(R.id.lll);
        b=(Button) findViewById(R.id.sss);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent r= new Intent(welcome.this,MainActivity.class);
                startActivity(r);
            }
        });
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    Intent w = new Intent(welcome.this, name.class);
                    startActivity(w);

            }
        });
    }
}
