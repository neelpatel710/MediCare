package com.example.gmit_sdp.beinghuman;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

/**
 * Created by DELL on 06-07-2017.
 */

public class timeduration extends Activity{
    Spinner spnDuration;
    Button g;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.time);
        g=(Button) findViewById(R.id.time_button);
        spnDuration = (Spinner)findViewById(R.id.spnDuration);

        String[] duration = { "1 day", "1 Week", "1 Month", "6 Month", "1 Year" };

        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,duration);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spnDuration.setAdapter(aa);
        g.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent u=new Intent(timeduration.this,barcode.class);
                startActivity(u);
            }
        });
    }
}
