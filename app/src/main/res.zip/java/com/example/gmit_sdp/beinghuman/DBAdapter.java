package com.example.gmit_sdp.beinghuman;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.preference.PreferenceManager;
import android.util.Log;

import java.util.HashMap;


/**
 * Created by DELL on 09-08-2017.
 */
/*public class DBAdapter {

    static final String KEY_ID="id_";
    static final String KEY_NAME="name";
    static final String KEY_PASSWORD="password";
    static final String KEY_EMAIL="email";
    static final String TAG="DBAdapter";
    static final String DATABASE_NAME="tollbooth";
    static final String DATABASE_TABLE="signup";
    static final int DATABASE_VERSION= 1;
    static final String DATABASE_CREATE="create table signup (id_ integer primary key autoincrement, name text not null,password text not null, email text not null)";
    final Context context;
    DatabaseHelper DBhelper;
    SQLiteDatabase db;

    public DBAdapter(Context ctx){
        this.context=ctx;
        DBhelper = new DatabaseHelper(context);
    }
    private static class DatabaseHelper extends SQLiteOpenHelper{
        DatabaseHelper(Context context)
        {
            super(context,DATABASE_NAME,null,DATABASE_VERSION);

        }


        @Override
        public void onCreate(SQLiteDatabase db)
        {
            try
            {
                db.execSQL(DATABASE_CREATE);
            }
            catch(SQLException e)
            {
                e.printStackTrace();
            }
        }
        @Override
        public void onUpgrade(SQLiteDatabase db,int oldVersion, int newVersion)
        {
            Log.w(TAG,"Upgrading database from version"+ oldVersion+"to"+ newVersion+"which will destroy the old data");
            db.execSQL("DROP table if exists contacts");
            onCreate(db);
        }
    }
    public  DBAdapter open()
    {
        db=DBhelper.getWritableDatabase();
        db=DBhelper.getReadableDatabase();
        return  this;
    }
    public void close()

    {
        DBhelper.close();
    }
    public long insertfield(String name, String password, String email)
    {
        ContentValues ivalues=new ContentValues();
        ivalues.put(KEY_NAME,name);
        ivalues.put(KEY_PASSWORD,password);
        ivalues.put(KEY_EMAIL,email);
        return db.insert(DATABASE_TABLE,null,ivalues);

    }
    public Cursor getAllField()
    {
        return db.query(DATABASE_TABLE,new String[]{KEY_ID,KEY_NAME,KEY_PASSWORD,KEY_EMAIL},null,null,null,null,null);
    }
    public String getSinlgeEntry(String username)
    {
        //String[] selectionArgs = new String[]{KEY_NAME};

        int i = 0;

        Cursor c=null;
            c = db.rawQuery("select * from signup where name ="+ username + "", null);

            //c = db.rawQuery("select * from signup where username=?", selectionArgs);
            i = c.getCount();
            if (i < 1) // UserName Not Exist
            {
                c.close();
                return "NOT EXIST";
            }
            String password = c.getString(c.getColumnIndex("password"));
            c.moveToFirst();
            c.close();
            return password;

    }
    /*public String getSinlgeEntry(String userName)
    {

        String[] column  = {KEY_NAME};
        Cursor cursor = db.query(DATABASE_TABLE, column,  " = " +  userName, null, null, null, null);
        //Cursor cursor = db.query(false,DATABASE_TABLE, " USERNAME=?", new String[]{userName}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password = cursor.getString(cursor.getColumnIndex("password"));
        cursor.close();
        return password;
    }*/

public class DBAdapter

{
    private static final String DATABASE_TABLE = "signup";
    public static final String KEY_ROW_ID = "_id";
    public static final String KEY_USERNAME = "name";
    public static final String KEY_PASSWORD = "password";
    public static final String KEY_EMAIL = "email";
    // Shared Preferences
    SharedPreferences pref;
    SharedPreferences.Editor editor;
    // Context
    Context mCtx;

    // Shared pref mode
    //int PRIVATE_MODE = 0;

    // Sharedpref file name
    private static final String PREF_NAME = "Tollbooth";

    // All Shared Preferences Keys
    private static final String IS_LOGIN = "IsLoggedIn";

    SQLiteDatabase mDb;

    DBHelper mDbHelper;

    public DBAdapter(Context context){
        mCtx = context;
        pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();
    }

    public DBAdapter open() throws SQLException {
        mDbHelper = new DBHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        if (null != mDbHelper)
            mDbHelper.close();
    }

    public long register(String user, String pw, String em) {
        mDbHelper = new DBHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_USERNAME, user);
        initialValues.put(KEY_PASSWORD, pw);
        initialValues.put(KEY_EMAIL, em);
        return mDb.insert(DATABASE_TABLE, null, initialValues);
    }
   /* public Cursor barcode(String user) {
        mDbHelper = new DBHelper(mCtx);
        mDb = mDbHelper.getReadableDatabase();
        Cursor mCursor = mDb.rawQuery("SELECT * FROM " + DATABASE_TABLE + " WHERE (name = ?)", new String[]{user});

        return mCursor;
    }*/
   public Cursor fetchOption(String user) throws SQLException {

       Cursor mCursor = mDb.query(true, DATABASE_TABLE, new String[] {KEY_ROW_ID,
                       KEY_USERNAME, KEY_EMAIL}, KEY_USERNAME + "=" + user, null,
               null, null, null, null);
       if (mCursor != null) {
           mCursor.moveToFirst();
       }
       return mCursor;

   }


    public boolean Login(String user, String password) throws SQLException {

        Cursor mCursor = mDb.rawQuery("SELECT * FROM " + DATABASE_TABLE + " WHERE (name = ? AND password = ?)", new String[]{user, password});
        //Cursor mCursor = mDb.rawQuery("SELECT * FROM " + DATABASE_TABLE + " WHERE (password = ?)", new String[]{password});

        if (mCursor != null) {
            if (mCursor.getCount() > 0) {

                return true;

            }
        }
        return false;
    }

    public boolean change(String userName, String strNewPin1) {

        Cursor cur = mDb.rawQuery("UPDATE " + DATABASE_TABLE + " SET " + KEY_PASSWORD + " = '" + strNewPin1 + "' WHERE " + KEY_USERNAME + "=?", new String[]{userName});

        if (cur != null) {
            if (cur.getCount() > 0) {

                return false;
            }
        }
        return true;
    }


    // User name (make variable public to access from outside)

    // Constructor

    /**
     * Create login session
     */
    public void createLoginSession(String name, String password) {
        // Storing login value as TRUE
        pref = mCtx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = pref.edit();

        editor.putBoolean(IS_LOGIN, true);

        // Storing name in pref
        editor.putString(KEY_USERNAME, name);

        // Storing email in pref
        editor.putString(KEY_PASSWORD, password);

        // commit changes
        editor.commit();
    }

    /**
     * Check login method wil check user login status
     * If false it will redirect user to login page
     * Else won't do anything
     */
    public void checkLogin() {

        // Check login status
        if (!this.isLoggedIn()) {
            // user is not logged in redirect him to Login Activity
            Intent i = new Intent(mCtx, welcome.class);
            // Closing all the Activities
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            // Add new Flag to start new Activity
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

            // Staring Login Activity
            mCtx.startActivity(i);
        } else {
            Intent r = new Intent(mCtx, bottom.class);
            mCtx.startActivity(r);
        }

    }


    /**
     * Get stored session data
     */
    public HashMap<String, String> getUserDetails() {
        HashMap<String, String> user = new HashMap<String, String>();
        // user name
        user.put(KEY_USERNAME, pref.getString(KEY_USERNAME, null));

        // user email id
        user.put(KEY_EMAIL, pref.getString(KEY_EMAIL, null));

        // return user
        return user;
    }
    public String createcode() {
        String user;// = new String();
        // user name
        pref = mCtx.getSharedPreferences(PREF_NAME,Context.MODE_PRIVATE);
        user = (pref.getString(KEY_USERNAME, ""));
        //user.put(pref.getString(KEY_USERNAME,null));
        // return user
        return user;
    }


    /**
     * Clear session details
     */
    public void logoutUser() {
        // Clearing all data from Shared Preferences
        editor.clear();
        editor.commit();

        // After logout redirect user to Loing Activity
        Intent i = new Intent(mCtx, welcome.class);
        // Closing all the Activities
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

        // Add new Flag to start new Activity
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        // Staring Login Activity
        mCtx.startActivity(i);
    }
    /**
     * Quick check for login
     **/
    // Get Login State
    public boolean isLoggedIn() {
        pref = mCtx.getSharedPreferences(PREF_NAME,Context.MODE_PRIVATE);
        return pref.getBoolean(IS_LOGIN, false);
    }
}

