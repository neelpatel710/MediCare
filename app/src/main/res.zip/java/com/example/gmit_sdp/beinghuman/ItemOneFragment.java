package com.example.gmit_sdp.beinghuman;


/**
 * Created by DELL on 02-08-2017.
 */

import android.graphics.Bitmap;
import android.os.Bundle;


        import android.os.Bundle;
import android.support.annotation.StringRes;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import net.glxn.qrgen.android.QRCode;
import net.glxn.qrgen.core.scheme.VCard;

import java.util.zip.Inflater;

public class ItemOneFragment extends Fragment {
    barcode bc;
    public static ItemOneFragment newInstance() {
        ItemOneFragment fragment = new ItemOneFragment();
        return fragment;
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v;
        v =  inflater.inflate(R.layout.fragment_item_one, container, false);
        bc = new barcode();
        bc.qrGenerator();
       /* ImageView imageview = (ImageView) v.findViewById(R.id.imageView);
        VCard yash =new VCard("yash")
                .setEmail("anand.abhay1910@gmail.com")
                .setAddress("India")
                .setTitle("Tutorial")
                .setCompany("studytutorial")
                .setPhoneNumber("258999")
                .setWebsite("www.studytutorial.in");
        Bitmap myBitmap= QRCode.from(yash).bitmap();
        imageview.setImageBitmap(myBitmap);*/


        return v;
    }


}
