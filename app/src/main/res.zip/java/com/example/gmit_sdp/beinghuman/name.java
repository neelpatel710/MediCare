package com.example.gmit_sdp.beinghuman;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by GMIT_SDP on 3/16/2017.
 */

public class name extends Activity {
    TextView fgp;
    EditText enter, th;
    Button b;
     DBAdapter dbAdapter;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);

     dbAdapter=new DBAdapter(name.this);
        enter = (EditText) findViewById(R.id.edt_txt);
        th = (EditText) findViewById(R.id.epsd);
        fgp = (TextView) findViewById(R.id.fgtpswd);
        b = (Button) findViewById(R.id.bttn);


        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try

                {
                    dbAdapter.open();
                }catch (Exception e)
                {
                    Log.e("dbAdapter id not open",dbAdapter.toString());
                }

                // get The User name and Password
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(enter.getWindowToken(), 0);
                imm.hideSoftInputFromWindow(th.getWindowToken(), 0);
                String userName=enter.getText().toString();

                String password=th.getText().toString();


                // fetch the Password form database for respective user name
                //String storedPassword=dbAdapter.getSinlgeEntry(userName);


                // check if the Stored password matches with  Password entered by user
                if(dbAdapter.Login(userName, password))
                {
                    dbAdapter.createLoginSession(userName,password);
                    Intent u =new Intent(name.this,bottom.class);

                    startActivity(u);
                }
                else
                {
                    Toast.makeText(name.this, "User Name or Password does not match", Toast.LENGTH_LONG).show();
                }

            }


        });

        fgp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                    Intent f = new Intent(name.this, forgot.class);
                    startActivity(f);



            }
        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close The Database
        if(null!=dbAdapter)
        dbAdapter.close();
    }
}
