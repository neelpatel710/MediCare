package com.example.gmit_sdp.beinghuman;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import net.glxn.qrgen.android.QRCode;
import net.glxn.qrgen.core.scheme.VCard;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by DELL on 28-07-2017.
 */

public class barcode extends Activity {
    DBAdapter dbAdapter;
    WindowManager manager;
    Display display;
    Point point;
    int width, height, smallestDimension;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        manager = (WindowManager) getSystemService(WINDOW_SERVICE);
        setContentView(R.layout.barcode);
        dbAdapter = new DBAdapter(getApplicationContext());
        display = manager.getDefaultDisplay();
        point = new Point();
        display.getSize(point);
        width = point.x;
        height = point.y;
        smallestDimension = width < height ? width : height;
        //b = new barcode();
        //ImageView myImage=(ImageView) findViewById(R.id.imageView);
        qrGenerator();


        /*Intent intent = new Intent("com.google.zxing.client.android.ENCODE");
        intent.putExtra("ENCODE_FORMAT", "QR_CODE");
        intent.putExtra("ENCODE_TYPE", "TEXT_TYPE");
        intent.putExtra("ENCODE_DATA", "http://www.techrepublic.com");

        try {
            startActivityForResult(intent,0);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + "com.google.zxing.client.android")));
        }*/
        /*VCard abhay=new VCard("Abhay")
                .setEmail("anand.abhay1910@gmail.com")
                .setAddress("India")
                .setTitle("Tutorial")
                .setCompany("studytutorial")
                .setPhoneNumber("258999")
                .setWebsite("www.studytutorial.in");
        Bitmap myBitmap= QRCode.from(abhay).bitmap();
        myImage.setImageBitmap(myBitmap);*/

    }

    public void qrGenerator() {

        /*dbAdapter=new DBAdapter(barcode.this);*/
        try {
            //setting size of qr code
           /* Display display = manager.getDefaultDisplay();
            Point point = new Point();
            display.getSize(point);
            int width = point.x;
            int height = point.y;
            int smallestDimension = width < height ? width : height;*/
            dbAdapter = new DBAdapter(getApplicationContext());
            String r = dbAdapter.createcode();
            String a = dbAdapter.fetchOption(r).getColumnName(0).toString();
            String b = dbAdapter.fetchOption(r).getColumnName(1).toString();
            String c = dbAdapter.fetchOption(r).getColumnName(2).toString();
            String[] qrInput = {a, b, c};

            //setting parameters for qr code
            String charset = "UTF-8"; // or "ISO-8859-1"
            Map<EncodeHintType, ErrorCorrectionLevel> hintMap = new HashMap<EncodeHintType, ErrorCorrectionLevel>();
            hintMap.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.L);
            createQRCode(a, charset, hintMap, smallestDimension, smallestDimension);

        } catch (Exception ex) {
            Log.e("QrGenerate", ex.getMessage());
        }
    }

    public void createQRCode(String qrCodeData, String charset, Map hintMap, int qrCodeheight, int qrCodewidth) {

        try {
            //generating qr code in bitmatrix type
            BitMatrix matrix = new MultiFormatWriter().encode(new String(qrCodeData.getBytes(charset), charset), BarcodeFormat.QR_CODE, qrCodewidth, qrCodeheight, hintMap);
            //converting bitmatrix to bitmap
            int width = matrix.getWidth();
            int height = matrix.getHeight();
            int[] pixels = new int[width * height];
            // All are 0, or black, by default
            for (int y = 0; y < height; y++) {
                int offset = y * width;
                for (int x = 0; x < width; x++) {
                    pixels[offset + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
                }
            }

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
            //setting bitmap to image view
            ImageView myImage = (ImageView) findViewById(R.id.imageView);
            myImage.setImageBitmap(bitmap);
        } catch (Exception er) {
            Log.e("QrGenerate", er.getMessage());
        }
    }

}


