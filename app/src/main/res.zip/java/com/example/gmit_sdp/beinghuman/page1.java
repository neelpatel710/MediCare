package com.example.gmit_sdp.beinghuman;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by DELL on 12-05-2017.
 */

public class page1 extends Activity {
    Button a1,a2,a3;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page);
        final DBAdapter db = new DBAdapter(this);
        a1=(Button) findViewById(R.id.button1);
        a2=(Button) findViewById(R.id.button2);
        a3=(Button) findViewById(R.id.button3);

        a1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent p=new Intent(page1.this,timeduration.class);
                startActivity(p);
            }

        });
        a2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent r=new Intent(page1.this,timeduration.class);
                startActivity(r);
            }
        });

        a3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent w=new Intent(page1.this,timeduration.class);
                startActivity(w);
            }
        });
    }

}
