package com.example.gmit_sdp.beinghuman;

/**
 * Created by DELL on 02-08-2017.
 */

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.HashMap;

public class ItemThreeFragment extends Fragment {
    Button logout;
    TextView name_display,email;


    public static ItemThreeFragment newInstance() {


        ItemThreeFragment fragment = new ItemThreeFragment();
        return fragment;

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        final DBAdapter dbAdapter=new DBAdapter(getActivity());
        final View h;
        TextView about_us;
        h = inflater.inflate(R.layout.fragment_item_three, container, false);
        name_display = (TextView) h.findViewById(R.id.lblName);
        email= (TextView) h.findViewById(R.id.lblEmail);
        about_us=(TextView) h.findViewById(R.id.aboutus);
        HashMap<String, String> user = dbAdapter.getUserDetails();
        String name = user.get(DBAdapter.KEY_USERNAME);

        // email
        String emailo = user.get(DBAdapter.KEY_EMAIL);
        // displaying user data
        name_display.setText(Html.fromHtml("Name: <b>" + name + "</b>"));
        email.setText(Html.fromHtml("Name: <b>" +emailo + "</b>"));
    about_us.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent r;
            r = new Intent(getActivity(),about_us.class);
            startActivity(r);
        }
    });

        Button logout=(Button) h.findViewById(R.id.logout_button);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dbAdapter.logoutUser();

            }
        });
        Bundle b = new Bundle();
        return h;
    }
}

