package com.example.gmit_sdp.beinghuman;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by GMIT_SDP on 3/30/2017.
 */

public class forgot extends Activity {
    EditText uname, unpswd,etConfirmPassword;
    Button y;
    DBAdapter dbAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forgot);
        uname=(EditText) findViewById(R.id.forgot);
        unpswd=(EditText) findViewById(R.id.entrnpswd);
        y=(Button) findViewById(R.id.nbtn);
        etConfirmPassword = (EditText) findViewById(R.id.et_confrim_pass);
        String name=getIntent().getStringExtra("name");
        uname.setText(name);
        dbAdapter=new DBAdapter(forgot.this);



        y.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usr,pswd,confimpswd;
                usr=uname.getText().toString().trim();
                pswd=unpswd.getText().toString().trim();
                confimpswd=etConfirmPassword.getText().toString().trim();
                try

                {
                    dbAdapter.open();
                }catch (Exception e)
                {
                    Log.e("dbAdapter id not open",dbAdapter.toString());
                }

                if (usr.equals("") || pswd.equals(""))
                {
                    Toast.makeText(getApplicationContext(),"Enter data",Toast.LENGTH_LONG).show();
                }
                else if (confimpswd.equals(pswd)){
                    if (dbAdapter.change(usr,pswd))
                    {
                        Toast.makeText(forgot.this, "Pin Change Successfully", Toast.LENGTH_LONG).show();
                        Intent b= new Intent(getApplicationContext(),bottom.class);
                        startActivity(b);
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"No such user found.",Toast.LENGTH_LONG).show();
                    }

                   }
                else{
                    Toast.makeText(getApplicationContext(),"passwword does not match",Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close The Database
        dbAdapter.close();
    }
}
